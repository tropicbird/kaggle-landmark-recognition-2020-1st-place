.. crcmod documentation master file, created by
   sphinx-quickstart on Thu Jan 21 14:04:12 2010.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

crcmod documentation
====================

This is the documentation for the :mod:`crcmod` Python library.

.. toctree::
   :maxdepth: 2

   intro.rst
   crcmod.rst
   crcmod.predefined.rst

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
